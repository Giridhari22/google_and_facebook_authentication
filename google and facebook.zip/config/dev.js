module.exports = {
  googleClientID:
    "320650663751-cotb0vah6olidasf8433jfse8aj3bkl3.apps.googleusercontent.com",
  googleClientSecret: "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",
  mongoURI:
    "mongodb://localhost:27017/nayaAshiyana",
  cookieKey: "hsdghsdghsd",
  FACEBOOK_APP_ID: "2183655625275997",
  FACEBOOK_APP_SECRET: "ba716e187750acf9eddaf74ba9fc37dc"
};



// CALLBACK_URL=http://localhost:3000/auth/google/callback
// CLIENT_ID=320650663751-cotb0vah6olidasf8433jfse8aj3bkl3.apps.googleusercontent.com
// CLIENT_SECRET=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